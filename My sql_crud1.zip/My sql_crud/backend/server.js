
const express = require("express");
const cors = require("cors");
const mysql = require("mysql");

const app = express();
app.use(express.json());
app.use(cors());


const db = mysql.createConnection({
    host: "localhost",
    user:"root",
    port:"3307",
    password:"password",
    database:"sql_workbench"
})
app.get("/",(req,res) => {
    const sql = "SELECT *FROM students";
    db.query(sql,(err,data) =>{
        if(err) return res.json(err);
        return res.json(data);
    })
})
app.post('/', (req, res) => {
    const {stu_id,stu_name,age,gender,doa,city} = req.body;
    console.log("Request body:", req.body);

    const sql = "INSERT INTO students (stu_id,stu_name, age, gender, doa, city) VALUES ( ?, ? , ?, ?,?,?)";
    db.query(sql, [stu_id,stu_name,age,gender,doa,city], (err, result) => {
        if(err) {
            console.error('Error executing SQL querry:', err);
            return res.status(500).json({error: err});
        }
        return res.status(201).json({message: 'students created successfully',result});
    });
});
app.put('/students/:stu_id', (req, res) => {
    const {stu_id} =req.params;
    const {stu_name,age,gender,doa,city} = req.body;
    console.log("Request body:", req.body);
    const sql="UPDATE students SET stu_name=?, age=?, gender=?, doa=?, city=? WHERE stu_id=?"
    db.query(sql, [stu_name,age,gender,doa,city,stu_id,], (err, result) => {
        if(err) {
            console.error('Error executing SQL querry:', err);
            return res.status(500).json({error: err});
        }
        return res.status(201).json({message: 'students created successfully',result});
    })

})
app.delete("/students/:stu_id",(req,res) => {
    const {stu_id}=req.params;
    const sql = "DELETE FROM students WHERE stu_id=?";
    db.query(sql,[stu_id],(err,data) =>{
        if(err) return res.json({error:err});
        return res.json(data);
    })
})

app.listen(3000, () => {
    console.log("listening");
})