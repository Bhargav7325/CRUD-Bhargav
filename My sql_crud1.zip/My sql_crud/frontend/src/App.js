
import './App.css'
import 'bootstrap/dist/css/bootstrap.min.css'
import {BrowserRouter, Route , Routes} from 'react-router-dom'
// eslint-disable-next-line no-unused-vars
import students from './student';

function App() {
  return(
    <div  className="App">
      <BrowserRouter>
      <Routes>
        <Route path='/' element = {<student/>}>
          </Route ></Routes></BrowserRouter>
    </div>
  );
}

export default App;
